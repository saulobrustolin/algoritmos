a = ['Volvo', 'Mercedes']
b = [5, 4]

# modelos
for x in range(0, len(a)):
    print(f'Modelo: {a[x]}')
    print(f'Km por litro: {b[x]}')

# inputs
t = int(input('Informa a distancia a ser percorrida em Km: '))
u = float(input('Informe o valor do litro do combustível: R$'))

# resultado

for x in range(0, len(a)):
    print(f'Modelo: {a[x]} Km/L: {b[x]} Consumo para {t} Km: {t/b[x]} Custo: R$ {(t/b[x])*u}')
