a = str(input('Digite seu nome: '))
b = []

i = 0
while i < 6:
    j = float(input(f'Digite a pontuação do disparo n°{i + 1}: '))

    if not j:
        print('Insira um valor!')
        continue

    b.append(j)

    i += 1

sort = 11
high = -1

print(f'Atirador: {a}')
for index, value in enumerate(b):
    if value < sort:
        sort = value
    if value > high:
        high = value

    print(f'Pontuação Disparo {index}: {value}')

b.remove(sort)
b.remove(high)

t = 0
for y in b:
    t += y

# resultado
print(f'\nResultado:')
print(f'Atirador: {a}')
print(f'Melhor pontuação: {high}')
print(f'Pior pontuação: {sort}')
print(f'Pontuação Final: {t / 4}')
